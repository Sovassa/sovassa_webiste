<?php
/**
 * Industries hub.
 *
 * @package Sovassa
 *
 * @var array<string, mixed> $args
 */

$page = $args['page'];
sovassa_page_hero($page, 'industries', 'One product interface surrounded by different markets.');
?>
<section class="section">
	<div class="container" data-switcher>
		<?php sovassa_section_head('Markets', 'Nine markets, each with its own page.', 'Open a market to see the problem we recognise and the services that usually sit together.'); ?>
		<div class="switcher__nav" hidden>
			<?php foreach ($page['items'] as $item) : ?>
				<button type="button" data-switch="<?php echo esc_attr(sanitize_title($item['title'])); ?>"><?php echo esc_html($item['title']); ?></button>
			<?php endforeach; ?>
		</div>
		<div class="card-grid card-grid--3">
			<?php foreach ($page['items'] as $item) : ?>
				<a class="link-card" id="<?php echo esc_attr(sanitize_title($item['title'])); ?>" data-switch-item="<?php echo esc_attr(sanitize_title($item['title'])); ?>" href="<?php echo esc_url(sovassa_url($item['slug'])); ?>">
					<h3><?php echo esc_html($item['title']); ?></h3>
					<p><strong>Challenge.</strong> <?php echo esc_html($item['challenge']); ?></p>
					<p><strong>How we help.</strong> <?php echo esc_html($item['support']); ?></p>
					<p class="link-card__kicker"><?php echo esc_html($item['combination']); ?></p>
				</a>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<section class="section section--tint">
	<div class="container split split--together">
		<div>
			<?php sovassa_section_head('Vertical Showcases', 'Engineered platform architectures across active markets.', 'Explore our flagship implementations in Telehealth & Patient Booking, High-Concurrency Ride-Hailing, and Multi-Vendor eCommerce Marketplaces.'); ?>
			<div class="btn-group">
				<a class="btn btn--primary" href="<?php echo esc_url(home_url('/work/')); ?>">Explore Flagship Case Studies <?php sovassa_icon('arrow'); ?></a>
				<a class="btn btn--ghost" href="<?php echo esc_url(home_url('/get-a-quote/')); ?>">Estimate Your Project</a>
			</div>
		</div>
		<?php sovassa_page_still('industries', 'A product interface surrounded by market clusters for commerce, care, learning, and finance.'); ?>
	</div>
</section>
<?php sovassa_faq($page['faq']); ?>
